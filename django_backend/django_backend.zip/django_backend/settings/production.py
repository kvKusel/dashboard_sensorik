# Import base settings
from .base import *

DEBUG = False

ALLOWED_HOSTS = []

# Allow for requests from the react server
CORS_ALLOWED_ORIGINS = []