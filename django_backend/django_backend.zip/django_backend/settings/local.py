# Import base settings
from .base import *

DEBUG = True
